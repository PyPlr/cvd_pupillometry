
PyPlr
=====

PyPlr is a Python library for researching the pupillary light reflex with the Pupil Core eye tracking ecosystem.

The code is here:

The documentation is here:


