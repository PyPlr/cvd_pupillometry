PyPlr
=====

*PyPlr* is a Python library for researching the pupillary light reflex with the Pupil Core eye tracking ecosystem. 

The code is here: https://github.com/PyPlr/cvd_pupillometry

The documentation is here: https://pyplr.github.io/cvd_pupillometry/index.html


